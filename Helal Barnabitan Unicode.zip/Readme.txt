Thank you for Purchasing our Premium Font.

All of our fonts are softwares which are licensed under some terms & conditions.
When buying and using our fonts, You must obey the following restriction otherwise your license is dismissed & you'll be exposed to legal actions. 

1. You CAN'T RESELL the fonts available on Lipighor as your own.
2. After purchase, You CAN'T upload the fonts on your website without our consent or proper legal permission.
3. You CAN'T change the font information, sell or distribute them as your own creation or intellectual property.
You can find elaborated End User License Agreement inside the file "EULA" file, read the file for explained User License Agreement terms & conditions.

If you're interested in Creating your own font, please contact us- admin@lipighor.com
